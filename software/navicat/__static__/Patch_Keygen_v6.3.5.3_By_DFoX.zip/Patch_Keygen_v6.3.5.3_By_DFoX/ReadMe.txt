1) Install Navicat x64 or x86
2) Use Patch/Keygen for Patch and Activation

Enjoy
..:: DeltaFoX ::..